#include "main.h"

/**
 * add - returns the sum of  the given parameters
 * @a: int type number
 * @b: int type number
 * Return: 0
*/

int add(int a, int b)
{
return (a + b);
}
