tasks for low-level programming
