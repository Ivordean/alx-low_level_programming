Project on c pointer and data structure
