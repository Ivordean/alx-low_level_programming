# Solutions to tasks on 0x1C. C - Makefiles
