DEbbuggin tasks
