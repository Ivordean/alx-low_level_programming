Driving more into pointers, arrays and strings in C
