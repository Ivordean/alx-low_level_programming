# C - Search Algorithms

![](https://www.freecodecamp.org/news/content/images/size/w2000/2022/01/searching.png)
