# 10 Variadic Funtions
