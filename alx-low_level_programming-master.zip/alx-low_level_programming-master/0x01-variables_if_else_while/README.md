task 001 for the ALX course on SE
