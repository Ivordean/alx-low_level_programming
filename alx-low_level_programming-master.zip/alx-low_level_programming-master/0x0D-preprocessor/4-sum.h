#ifndef _SUM_
#define _SUM_
#define SUM(x, y) ((x) + (y))

#endif
