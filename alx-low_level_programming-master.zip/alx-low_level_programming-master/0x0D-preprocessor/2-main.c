#include <stdio.h>
/**
 * main - function to print name of file
 *
 * Return: file name on execution
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
