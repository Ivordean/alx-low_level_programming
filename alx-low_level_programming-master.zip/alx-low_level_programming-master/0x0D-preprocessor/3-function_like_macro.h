#ifndef HEADER
#define HEADER
#define ABS(x) ((x) < 0 ? ((x) * -1) : (x))

#endif
