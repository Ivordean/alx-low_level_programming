#include <stdio.h>
/**
 * main - entry point of program
 * @argc: size of argv to be printed
 * @argv: variable to be filled with block
 * Return: argv
 */
int main(int argc, char *argv[])
{
	(void)argc;

	printf("%s\n", argv[0]);
	return (0);
}
