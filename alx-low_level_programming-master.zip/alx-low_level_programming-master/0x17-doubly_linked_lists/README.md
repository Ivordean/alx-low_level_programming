# **0x17. C - Doubly linked lists** #
### **C**
### **Algorithm**
### **Data structure**
___
## **Tasks** ##
___
  **0. Print list**
___
  **1. List length**
___
  **2. Add node**
___
  **3. Add node at the end**
___
  **4. Free list**
___
  **5. Get node at index**
___
  **6. Sum list**
___
  **7. Insert at index**
___
  **8. Delete at index**
___
  **9. Crackme4**
___
  **10. Palindromes**
___
  **11. crackme5**
___
  
## Author
### Afolabi Oluwaseun John
