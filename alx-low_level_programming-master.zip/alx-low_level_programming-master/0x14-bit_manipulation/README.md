
# 0x14. C - Bit manipulation

- Logical AND --> &
- Logical OR --> |
- Shift right and left
- Negation/ complement --> ~

